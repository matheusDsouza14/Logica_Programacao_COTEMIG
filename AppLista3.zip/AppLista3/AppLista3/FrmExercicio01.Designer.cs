﻿namespace AppLista3
{
    partial class FrmExercicio01
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.txtNum2 = new System.Windows.Forms.TextBox();
            this.txtNum3 = new System.Windows.Forms.TextBox();
            this.lblNum1 = new System.Windows.Forms.Label();
            this.lblNum2 = new System.Windows.Forms.Label();
            this.lblNum3 = new System.Windows.Forms.Label();
            this.btnSoma = new System.Windows.Forms.Button();
            this.btnmPorcentagem = new System.Windows.Forms.Button();
            this.btnMédia = new System.Windows.Forms.Button();
            this.lblResultado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtNum1
            // 
            this.txtNum1.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNum1.Location = new System.Drawing.Point(38, 93);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(220, 32);
            this.txtNum1.TabIndex = 0;
            this.txtNum1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtNum2
            // 
            this.txtNum2.Font = new System.Drawing.Font("Times New Roman", 15.75F);
            this.txtNum2.Location = new System.Drawing.Point(41, 177);
            this.txtNum2.Name = "txtNum2";
            this.txtNum2.Size = new System.Drawing.Size(217, 32);
            this.txtNum2.TabIndex = 1;
            // 
            // txtNum3
            // 
            this.txtNum3.Font = new System.Drawing.Font("Times New Roman", 15.75F);
            this.txtNum3.Location = new System.Drawing.Point(41, 270);
            this.txtNum3.Name = "txtNum3";
            this.txtNum3.Size = new System.Drawing.Size(217, 32);
            this.txtNum3.TabIndex = 2;
            // 
            // lblNum1
            // 
            this.lblNum1.AutoSize = true;
            this.lblNum1.Font = new System.Drawing.Font("Times New Roman", 15.75F);
            this.lblNum1.Location = new System.Drawing.Point(34, 57);
            this.lblNum1.Name = "lblNum1";
            this.lblNum1.Size = new System.Drawing.Size(224, 23);
            this.lblNum1.TabIndex = 3;
            this.lblNum1.Text = "Digite o primeiro número";
            this.lblNum1.Click += new System.EventHandler(this.lblNum1_Click);
            // 
            // lblNum2
            // 
            this.lblNum2.AutoSize = true;
            this.lblNum2.Font = new System.Drawing.Font("Times New Roman", 15.75F);
            this.lblNum2.Location = new System.Drawing.Point(37, 139);
            this.lblNum2.Name = "lblNum2";
            this.lblNum2.Size = new System.Drawing.Size(221, 23);
            this.lblNum2.TabIndex = 4;
            this.lblNum2.Text = "Digite o segundo número";
            // 
            // lblNum3
            // 
            this.lblNum3.AutoSize = true;
            this.lblNum3.Font = new System.Drawing.Font("Times New Roman", 15.75F);
            this.lblNum3.Location = new System.Drawing.Point(42, 233);
            this.lblNum3.Name = "lblNum3";
            this.lblNum3.Size = new System.Drawing.Size(216, 23);
            this.lblNum3.TabIndex = 5;
            this.lblNum3.Text = "Digite o terceiro número";
            // 
            // btnSoma
            // 
            this.btnSoma.Font = new System.Drawing.Font("Times New Roman", 15.75F);
            this.btnSoma.Location = new System.Drawing.Point(38, 340);
            this.btnSoma.Name = "btnSoma";
            this.btnSoma.Size = new System.Drawing.Size(107, 70);
            this.btnSoma.TabIndex = 6;
            this.btnSoma.Text = "Calcular Soma";
            this.btnSoma.UseVisualStyleBackColor = true;
            this.btnSoma.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnmPorcentagem
            // 
            this.btnmPorcentagem.Font = new System.Drawing.Font("Times New Roman", 15.75F);
            this.btnmPorcentagem.Location = new System.Drawing.Point(154, 339);
            this.btnmPorcentagem.Name = "btnmPorcentagem";
            this.btnmPorcentagem.Size = new System.Drawing.Size(133, 71);
            this.btnmPorcentagem.TabIndex = 7;
            this.btnmPorcentagem.Text = "Calcular Porcentagem";
            this.btnmPorcentagem.UseVisualStyleBackColor = true;
            this.btnmPorcentagem.Click += new System.EventHandler(this.btnmMédia_Click);
            // 
            // btnMédia
            // 
            this.btnMédia.Font = new System.Drawing.Font("Times New Roman", 15.75F);
            this.btnMédia.Location = new System.Drawing.Point(302, 341);
            this.btnMédia.Name = "btnMédia";
            this.btnMédia.Size = new System.Drawing.Size(104, 69);
            this.btnMédia.TabIndex = 8;
            this.btnMédia.Text = "Calcular Média";
            this.btnMédia.UseVisualStyleBackColor = true;
            this.btnMédia.Click += new System.EventHandler(this.btnMédia_Click);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Times New Roman", 15.75F);
            this.lblResultado.Location = new System.Drawing.Point(38, 443);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(0, 23);
            this.lblResultado.TabIndex = 9;
            // 
            // FrmExercicio01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(434, 529);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.btnMédia);
            this.Controls.Add(this.btnmPorcentagem);
            this.Controls.Add(this.btnSoma);
            this.Controls.Add(this.lblNum3);
            this.Controls.Add(this.lblNum2);
            this.Controls.Add(this.lblNum1);
            this.Controls.Add(this.txtNum3);
            this.Controls.Add(this.txtNum2);
            this.Controls.Add(this.txtNum1);
            this.Name = "FrmExercicio01";
            this.Text = "Exercicio01";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNum1;
        private System.Windows.Forms.TextBox txtNum2;
        private System.Windows.Forms.TextBox txtNum3;
        private System.Windows.Forms.Label lblNum1;
        private System.Windows.Forms.Label lblNum2;
        private System.Windows.Forms.Label lblNum3;
        private System.Windows.Forms.Button btnSoma;
        private System.Windows.Forms.Button btnmPorcentagem;
        private System.Windows.Forms.Button btnMédia;
        private System.Windows.Forms.Label lblResultado;
    }
}

