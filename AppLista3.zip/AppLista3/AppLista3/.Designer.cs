﻿namespace AppLista3
{
    partial class FrmExercicio02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlPetrolioBras = new System.Windows.Forms.Panel();
            this.lblPetrolioBrasil = new System.Windows.Forms.Label();
            this.lblValLitro = new System.Windows.Forms.Label();
            this.lblValPagar = new System.Windows.Forms.Label();
            this.txtValGas = new System.Windows.Forms.TextBox();
            this.txtValPag = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblResultado = new System.Windows.Forms.Label();
            this.pnlPetrolioBras.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlPetrolioBras
            // 
            this.pnlPetrolioBras.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(214)))), ((int)(((byte)(10)))));
            this.pnlPetrolioBras.Controls.Add(this.lblPetrolioBrasil);
            this.pnlPetrolioBras.Location = new System.Drawing.Point(-2, -3);
            this.pnlPetrolioBras.Name = "pnlPetrolioBras";
            this.pnlPetrolioBras.Size = new System.Drawing.Size(466, 135);
            this.pnlPetrolioBras.TabIndex = 0;
            // 
            // lblPetrolioBrasil
            // 
            this.lblPetrolioBrasil.AutoSize = true;
            this.lblPetrolioBrasil.BackColor = System.Drawing.Color.Transparent;
            this.lblPetrolioBrasil.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPetrolioBrasil.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblPetrolioBrasil.Location = new System.Drawing.Point(34, 49);
            this.lblPetrolioBrasil.Name = "lblPetrolioBrasil";
            this.lblPetrolioBrasil.Size = new System.Drawing.Size(187, 36);
            this.lblPetrolioBrasil.TabIndex = 0;
            this.lblPetrolioBrasil.Text = "PetrolioBras";
            //this.lblPetrolioBrasil.Click += new System.EventHandler(this.lblPetrolioBrasil_Click);
            // 
            // lblValLitro
            // 
            this.lblValLitro.AutoSize = true;
            this.lblValLitro.Font = new System.Drawing.Font("Times New Roman", 15.75F);
            this.lblValLitro.Location = new System.Drawing.Point(21, 184);
            this.lblValLitro.Name = "lblValLitro";
            this.lblValLitro.Size = new System.Drawing.Size(132, 23);
            this.lblValLitro.TabIndex = 1;
            this.lblValLitro.Text = "Preço por litro";
            //this.lblValLitro.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblValPagar
            // 
            this.lblValPagar.AutoSize = true;
            this.lblValPagar.Font = new System.Drawing.Font("Times New Roman", 15.75F);
            this.lblValPagar.Location = new System.Drawing.Point(28, 246);
            this.lblValPagar.Name = "lblValPagar";
            this.lblValPagar.Size = new System.Drawing.Size(122, 23);
            this.lblValPagar.TabIndex = 2;
            this.lblValPagar.Text = "Valor a Pagar";
            // 
            // txtValGas
            // 
            this.txtValGas.Font = new System.Drawing.Font("Times New Roman", 15.75F);
            this.txtValGas.Location = new System.Drawing.Point(173, 184);
            this.txtValGas.Name = "txtValGas";
            this.txtValGas.Size = new System.Drawing.Size(149, 32);
            this.txtValGas.TabIndex = 3;
            //this.txtValGas.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtValPag
            // 
            this.txtValPag.Font = new System.Drawing.Font("Times New Roman", 15.75F);
            this.txtValPag.Location = new System.Drawing.Point(173, 249);
            this.txtValPag.Name = "txtValPag";
            this.txtValPag.Size = new System.Drawing.Size(149, 32);
            this.txtValPag.TabIndex = 4;
            // 
            // btnCalcular
            // 
            this.btnCalcular.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCalcular.Font = new System.Drawing.Font("Times New Roman", 15.75F);
            this.btnCalcular.Location = new System.Drawing.Point(32, 304);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(112, 47);
            this.btnCalcular.TabIndex = 5;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Times New Roman", 15.75F);
            this.lblResultado.Location = new System.Drawing.Point(34, 383);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(0, 23);
            this.lblResultado.TabIndex = 6;
            this.lblResultado.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // FrmExercicio02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(129)))), ((int)(((byte)(87)))));
            this.ClientSize = new System.Drawing.Size(461, 450);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtValPag);
            this.Controls.Add(this.txtValGas);
            this.Controls.Add(this.lblValPagar);
            this.Controls.Add(this.lblValLitro);
            this.Controls.Add(this.pnlPetrolioBras);
            this.Name = "FrmExercicio02";
            this.Text = "Exercicio2";
//            this.Load += new System.EventHandler(this.FrmExercicio02_Load);
            this.pnlPetrolioBras.ResumeLayout(false);
            this.pnlPetrolioBras.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlPetrolioBras;
        private System.Windows.Forms.Label lblPetrolioBrasil;
        private System.Windows.Forms.Label lblValLitro;
        private System.Windows.Forms.Label lblValPagar;
        private System.Windows.Forms.TextBox txtValGas;
        private System.Windows.Forms.TextBox txtValPag;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblResultado;
    }
}