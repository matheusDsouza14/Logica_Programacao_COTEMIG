﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista3
{
    public partial class FrmExercicio03 : Form
    {
        public FrmExercicio03()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnResultado_Click(object sender, EventArgs e)
        {
            //Receber valores
            float pesRef = float.Parse(txtPesRef.Text);
            float resultado;
            //Processamento
            resultado = pesRef*34 
            lblResultado.Text = "O valor total da refeição é: " + resultado

        }

    }
}
