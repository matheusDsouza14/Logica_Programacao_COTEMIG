﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista3
{
    public partial class FrmExercicio01 : Form
    {
        public FrmExercicio01()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           //Receber números
           float num1 = float.Parse(txtNum1.Text);
           float num2 = float.Parse(txtNum1.Text);
           float num3 = float.Parse(txtNum1.Text);
           float resultado;
            //Procesar
            resultado = num1 + num2 + num3;
            lblResultado.Text = "Resultado = " + resultado;
        }

        private void btnmMédia_Click(object sender, EventArgs e)
        {
            //Receber números
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum1.Text);
            float num3 = float.Parse(txtNum1.Text);
            float resultado;
            float porcnum1;
            float porcnum2;
            float porcnum3;
            //Procesar
            resultado = num1 + num2 + num3;
            lblResultado.Text = "Resultado = " + resultado;
        }

        private void btnMédia_Click(object sender, EventArgs e)
        {
            //Receber números
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum1.Text);
            float num3 = float.Parse(txtNum1.Text);
            float resultado;
            //Procesar
            resultado = (num1 + num2 + num3)/3;
            lblResultado.Text = "Resultado = " + resultado;
        }
    }
}
