﻿namespace AppLista3
{
    partial class FrmExercicio03
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnResultado = new System.Windows.Forms.Button();
            this.lblFornoSP = new System.Windows.Forms.Label();
            this.lblSubtitulo = new System.Windows.Forms.Label();
            this.txtPesRef = new System.Windows.Forms.TextBox();
            this.lblPesRef = new System.Windows.Forms.Label();
            this.lblResultado = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel1.Controls.Add(this.lblSubtitulo);
            this.panel1.Controls.Add(this.lblFornoSP);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(467, 222);
            this.panel1.TabIndex = 0;
            // 
            // btnResultado
            // 
            this.btnResultado.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold);
            this.btnResultado.Location = new System.Drawing.Point(41, 378);
            this.btnResultado.Name = "btnResultado";
            this.btnResultado.Size = new System.Drawing.Size(110, 45);
            this.btnResultado.TabIndex = 1;
            this.btnResultado.Text = "Calcular";
            this.btnResultado.UseVisualStyleBackColor = true;
            this.btnResultado.Click += new System.EventHandler(this.btnResultado_Click);
            // 
            // lblFornoSP
            // 
            this.lblFornoSP.AutoSize = true;
            this.lblFornoSP.BackColor = System.Drawing.Color.Transparent;
            this.lblFornoSP.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFornoSP.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lblFornoSP.Location = new System.Drawing.Point(46, 86);
            this.lblFornoSP.Name = "lblFornoSP";
            this.lblFornoSP.Size = new System.Drawing.Size(245, 24);
            this.lblFornoSP.TabIndex = 0;
            this.lblFornoSP.Text = "FORNO DE SÃO PAULO";
            this.lblFornoSP.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblSubtitulo
            // 
            this.lblSubtitulo.AutoSize = true;
            this.lblSubtitulo.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblSubtitulo.Location = new System.Drawing.Point(47, 120);
            this.lblSubtitulo.Name = "lblSubtitulo";
            this.lblSubtitulo.Size = new System.Drawing.Size(104, 13);
            this.lblSubtitulo.TabIndex = 1;
            this.lblSubtitulo.Text = "Restaurante paulista";
            // 
            // txtPesRef
            // 
            this.txtPesRef.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold);
            this.txtPesRef.Location = new System.Drawing.Point(41, 314);
            this.txtPesRef.Name = "txtPesRef";
            this.txtPesRef.Size = new System.Drawing.Size(240, 32);
            this.txtPesRef.TabIndex = 2;
            // 
            // lblPesRef
            // 
            this.lblPesRef.AutoSize = true;
            this.lblPesRef.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPesRef.Location = new System.Drawing.Point(37, 271);
            this.lblPesRef.Name = "lblPesRef";
            this.lblPesRef.Size = new System.Drawing.Size(396, 19);
            this.lblPesRef.TabIndex = 3;
            this.lblPesRef.Text = "Digite o peso da sua refeição(preço por kg: R$34,00)";
//            this.lblPesRef.Click += new System.EventHandler(this.lblPesRef_Click);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold);
            this.lblResultado.Location = new System.Drawing.Point(46, 454);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(0, 24);
            this.lblResultado.TabIndex = 4;
            // 
            // FrmExercicio03
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(466, 557);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.lblPesRef);
            this.Controls.Add(this.txtPesRef);
            this.Controls.Add(this.btnResultado);
            this.Controls.Add(this.panel1);
            this.Name = "FrmExercicio03";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblFornoSP;
        private System.Windows.Forms.Button btnResultado;
        private System.Windows.Forms.Label lblSubtitulo;
        private System.Windows.Forms.TextBox txtPesRef;
        private System.Windows.Forms.Label lblPesRef;
        private System.Windows.Forms.Label lblResultado;
    }
}