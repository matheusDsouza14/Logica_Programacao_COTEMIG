﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista3
{
    public partial class FrmExercicio02 : Form
    {
        public FrmExercicio02()
        {
            InitializeComponent();
        }


        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //receber valores
            float valgas = float.Parse(txtValGas.Text);
            float valpag = float.Parse(txtValPag.Text);
            float resultado;
            //Processar
            resultado = valpag / valgas;
            lblResultado.Text = "O valor pago será: " + resultado;
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }
    }
}
