﻿namespace AppSimulado_Matheus_Del_lAreti_2A2
{
    partial class FrmExercicio1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnHFW = new System.Windows.Forms.Button();
            this.btnMML = new System.Windows.Forms.Button();
            this.btnGT7 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnHFW
            // 
            this.btnHFW.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold);
            this.btnHFW.Location = new System.Drawing.Point(39, 192);
            this.btnHFW.Name = "btnHFW";
            this.btnHFW.Size = new System.Drawing.Size(245, 41);
            this.btnHFW.TabIndex = 0;
            this.btnHFW.Text = "Horizon Forbidden West";
            this.btnHFW.UseVisualStyleBackColor = true;
            // 
            // btnMML
            // 
            this.btnMML.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMML.Location = new System.Drawing.Point(39, 261);
            this.btnMML.Name = "btnMML";
            this.btnMML.Size = new System.Drawing.Size(245, 61);
            this.btnMML.TabIndex = 1;
            this.btnMML.Text = "Marvel\'s Spiderman: Miles Morales";
            this.btnMML.UseVisualStyleBackColor = true;
            this.btnMML.Click += new System.EventHandler(this.btnMML_Click);
            // 
            // btnGT7
            // 
            this.btnGT7.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold);
            this.btnGT7.Location = new System.Drawing.Point(39, 361);
            this.btnGT7.Name = "btnGT7";
            this.btnGT7.Size = new System.Drawing.Size(245, 43);
            this.btnGT7.TabIndex = 2;
            this.btnGT7.Text = "Grand Turismo™ 7";
            this.btnGT7.UseVisualStyleBackColor = true;
            // 
            // FrmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(491, 479);
            this.Controls.Add(this.btnGT7);
            this.Controls.Add(this.btnMML);
            this.Controls.Add(this.btnHFW);
            this.Name = "FrmExercicio1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnHFW;
        private System.Windows.Forms.Button btnMML;
        private System.Windows.Forms.Button btnGT7;
    }
}

